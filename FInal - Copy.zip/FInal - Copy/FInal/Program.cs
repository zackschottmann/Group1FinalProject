﻿
using var game = new FInal.Game1();
game.Run();
