﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media; // For background music
using Microsoft.Xna.Framework.Audio; // For sound effects
using System.Collections.Generic;
using System;

namespace FInal
{
    public class Game1 : Game
    {
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;

        private Texture2D _backgroundTexture;
        private Texture2D _playerTexture;
        private Texture2D _enemyTexture;
        private Texture2D _bulletTexture;

        private SoundEffect _shootSound;
        private SoundEffect _explosionSound;
        private Song _backgroundMusic;

        private Vector2 _playerPosition;
        private float _playerSpeed = 300f; // Increased player speed
        private float _playerScale = 0.8f; // Scale player to 80% of original size

        private Vector2 _backgroundPosition1;
        private Vector2 _backgroundPosition2;
        private float _backgroundScrollSpeed = 100f; // Background scroll speed

        private List<Enemy> _enemies = new List<Enemy>();
        private List<Bullet> _bullets = new List<Bullet>();

        private double _enemySpawnTimer = 0;
        private double _bulletCooldownTimer = 0;
        private double _gameTimer = 0;

        private int _playerScore = 0;
        private static Random Rand = new Random();

        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
        }

        protected override void Initialize()
        {
            _graphics.PreferredBackBufferWidth = 1024; // Increased width
            _graphics.PreferredBackBufferHeight = 768; // Increased height
            _graphics.ApplyChanges();

            _playerPosition = new Vector2(512, 700); // Updated to fit new window size

            // Initialize background positions
            _backgroundPosition1 = Vector2.Zero;
            _backgroundPosition2 = new Vector2(0, -_graphics.PreferredBackBufferHeight);

            base.Initialize();
        }

        protected override void LoadContent()
        {
            _spriteBatch = new SpriteBatch(GraphicsDevice);
            _backgroundTexture = Content.Load<Texture2D>("Graphics/Backround");
            _playerTexture = Content.Load<Texture2D>("Graphics/SpaceShip");
            _enemyTexture = Content.Load<Texture2D>("Graphics/enemy");
            _bulletTexture = Content.Load<Texture2D>("Graphics/Bullet");

            _shootSound = Content.Load<SoundEffect>("Audio/invaderkilled");
            _explosionSound = Content.Load<SoundEffect>("Audio/invaderkilled");
            _backgroundMusic = Content.Load<Song>("Audio/space-station-247790");

            MediaPlayer.IsRepeating = true;
            MediaPlayer.Play(_backgroundMusic);
        }

        protected override void Update(GameTime gameTime)
        {
            if (Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            _gameTimer += gameTime.ElapsedGameTime.TotalSeconds;

            HandlePlayerInput(gameTime);
            UpdateBackground(gameTime); // Add this call
            UpdateEnemies(gameTime);
            UpdateBullets(gameTime);
            SpawnEnemies(gameTime);

            CheckWinOrLossConditions();

            base.Update(gameTime);
        }

        private void HandlePlayerInput(GameTime gameTime)
        {
            KeyboardState state = Keyboard.GetState();
            float deltaTime = (float)gameTime.ElapsedGameTime.TotalSeconds;

            if (state.IsKeyDown(Keys.Left) && _playerPosition.X > 0)
                _playerPosition.X -= _playerSpeed * deltaTime;

            if (state.IsKeyDown(Keys.Right) && _playerPosition.X < _graphics.PreferredBackBufferWidth - (_playerTexture.Width * _playerScale))
                _playerPosition.X += _playerSpeed * deltaTime;

            if (state.IsKeyDown(Keys.Up) && _playerPosition.Y > 0)
                _playerPosition.Y -= _playerSpeed * deltaTime;

            if (state.IsKeyDown(Keys.Down) && _playerPosition.Y < _graphics.PreferredBackBufferHeight - (_playerTexture.Height * _playerScale))
                _playerPosition.Y += _playerSpeed * deltaTime;

            if (state.IsKeyDown(Keys.Space))
            {
                if (_bulletCooldownTimer <= 0)
                {
                    ShootBullet();
                    _bulletCooldownTimer = 0.5;
                }
            }

            _bulletCooldownTimer -= deltaTime;
        }

        private void ShootBullet()
        {
            Vector2 bulletPosition = new Vector2(
                _playerPosition.X + (_playerTexture.Width * _playerScale) / 2 - _bulletTexture.Width / 2,
                _playerPosition.Y);
            _bullets.Add(new Bullet(_bulletTexture, bulletPosition, new Vector2(0, -400)));
            _shootSound.Play();
        }

        private void UpdateEnemies(GameTime gameTime)
        {
            foreach (var enemy in _enemies.ToArray()) // Use ToArray to allow modifications during iteration
            {
                // Update enemy position and check if it's alive
                enemy.Update(gameTime, _graphics.PreferredBackBufferWidth, _graphics.PreferredBackBufferHeight);

                if (!enemy.IsAlive)
                {
                    _enemies.Remove(enemy);
                }
                else if (CollisionDetection.CheckCollision(
                    new Rectangle(
                        (int)_playerPosition.X,
                        (int)_playerPosition.Y,
                        (int)(_playerTexture.Width * _playerScale),
                        (int)(_playerTexture.Height * _playerScale)),
                    enemy.BoundingBox))
                {
                    EndGame("You blew up!");
                }
            }
        }

        private void UpdateBullets(GameTime gameTime)
        {
            foreach (var bullet in _bullets.ToArray()) // Use ToArray to allow modifications during iteration
            {
                // Update bullet position
                bullet.Update(gameTime);

                // Remove bullets out of screen bounds
                if (bullet.Position.Y < 0)
                {
                    _bullets.Remove(bullet);
                }

                // Check collision between bullets and enemies
                foreach (var enemy in _enemies.ToArray())
                {
                    if (CollisionDetection.CheckCollision(bullet.BoundingBox, enemy.BoundingBox))
                    {
                        _explosionSound.Play();
                        _bullets.Remove(bullet);
                        _enemies.Remove(enemy);
                        _playerScore++;
                        break; // Break out of the enemy loop once the bullet is removed
                    }
                }
            }
        }



        private void UpdateBackground(GameTime gameTime)
        {
            float deltaTime = (float)gameTime.ElapsedGameTime.TotalSeconds;

            // Scroll background upward
            _backgroundPosition1.Y += _backgroundScrollSpeed * deltaTime;
            _backgroundPosition2.Y += _backgroundScrollSpeed * deltaTime;

            // Reset positions when background moves off-screen
            if (_backgroundPosition1.Y >= _graphics.PreferredBackBufferHeight)
                _backgroundPosition1.Y = _backgroundPosition2.Y - _graphics.PreferredBackBufferHeight;

            if (_backgroundPosition2.Y >= _graphics.PreferredBackBufferHeight)
                _backgroundPosition2.Y = _backgroundPosition1.Y - _graphics.PreferredBackBufferHeight;
        }

        private void SpawnEnemies(GameTime gameTime)
        {
            _enemySpawnTimer += gameTime.ElapsedGameTime.TotalSeconds;

            if (_enemySpawnTimer >= 1.0)
            {
                Vector2 position = new Vector2(
                    Rand.Next(0, _graphics.PreferredBackBufferWidth - (int)(_enemyTexture.Width * 0.5f)), 0);
                Vector2 velocity = new Vector2(0, Rand.Next(100, 300));
                Enemy enemy = new Enemy(_enemyTexture, position, velocity) { Scale = 0.5f };
                _enemies.Add(enemy);
                _enemySpawnTimer = 0;
            }
        }

        private void CheckWinOrLossConditions()
        {
            if (_playerScore >= 10)
                EndGame("You won!");

            if (_gameTimer >= 20)
                EndGame("Mission over! Too slow!");
        }

        private void EndGame(string message)
        {
            MediaPlayer.Stop();
            Console.WriteLine(message);
            Exit();
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.Black);
            _spriteBatch.Begin();

            // Draw scaled and looping backgrounds
            _spriteBatch.Draw(
                _backgroundTexture,
                _backgroundPosition1,
                null,
                Color.White,
                0f,
                Vector2.Zero,
                new Vector2(
                    _graphics.PreferredBackBufferWidth / (float)_backgroundTexture.Width,
                    _graphics.PreferredBackBufferHeight / (float)_backgroundTexture.Height),
                SpriteEffects.None,
                0f);

            _spriteBatch.Draw(
                _backgroundTexture,
                _backgroundPosition2,
                null,
                Color.White,
                0f,
                Vector2.Zero,
                new Vector2(
                    _graphics.PreferredBackBufferWidth / (float)_backgroundTexture.Width,
                    _graphics.PreferredBackBufferHeight / (float)_backgroundTexture.Height),
                SpriteEffects.None,
                0f);

            // Draw scaled player
            _spriteBatch.Draw(
                _playerTexture,
                _playerPosition,
                null,
                Color.White,
                0f,
                Vector2.Zero,
                _playerScale,
                SpriteEffects.None,
                0f);

            foreach (var enemy in _enemies)
                enemy.Draw(_spriteBatch);

            foreach (var bullet in _bullets)
                bullet.Draw(_spriteBatch);

            _spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
