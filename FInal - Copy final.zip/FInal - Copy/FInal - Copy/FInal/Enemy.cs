﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace FInal
{
    internal class Enemy
    {
        public Vector2 Position { get; private set; }
        public Vector2 Velocity { get; private set; }
        public Texture2D Texture { get; private set; }
        public Rectangle BoundingBox { get; private set; }
        public bool IsAlive { get; private set; } = true;
        public float Scale { get; set; } = 1.0f;

        public Enemy(Texture2D texture, Vector2 position, Vector2 velocity)
        {
            Texture = texture;
            Position = position;
            Velocity = velocity;

            // Initialize the bounding box
            UpdateBoundingBox();
        }

        public void Update(GameTime gameTime, float screenWidth, float screenHeight)
        {
            // Update position based on velocity
            Position += Velocity * (float)gameTime.ElapsedGameTime.TotalSeconds;

            // Mark the enemy as not alive if it moves off-screen
            if (Position.Y > screenHeight || Position.X < 0 || Position.X > screenWidth - (Texture.Width * Scale))
            {
                IsAlive = false;
            }

            // Update bounding box
            UpdateBoundingBox();
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            if (IsAlive)
            {
                spriteBatch.Draw(Texture, Position, null, Color.White, 0f, Vector2.Zero, Scale, SpriteEffects.None, 0f);
            }
        }

        private void UpdateBoundingBox()
        {
            BoundingBox = new Rectangle(
                (int)Position.X,
                (int)Position.Y,
                (int)(Texture.Width * Scale),
                (int)(Texture.Height * Scale));
        }
    }
}
