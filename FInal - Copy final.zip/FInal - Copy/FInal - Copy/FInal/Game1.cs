﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Audio;
using System.Collections.Generic;
using System;

namespace FInal
{
    public enum GameState
    {
        MainMenu,
        Playing,
        GameOver
    }

    public class Game1 : Game
    {
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;

        private Texture2D _backgroundTexture;
        private Texture2D _playerTexture;
        private Texture2D _enemyTexture;
        private Texture2D _bulletTexture;
        private Texture2D _startButtonTexture;

        private Rectangle _startButtonRectangle;

        private SoundEffect _shootSound;
        private SoundEffect _explosionSound;
        private Song _backgroundMusic;

        private Vector2 _playerPosition;
        private float _playerSpeed = 300f;
        private float _playerScale = 0.8f;

        private Vector2 _backgroundPosition1;
        private Vector2 _backgroundPosition2;
        private float _backgroundScrollSpeed = 100f;

        private List<Enemy> _enemies = new List<Enemy>();
        private List<Bullet> _bullets = new List<Bullet>();

        private double _enemySpawnTimer = 0; // Fixed warning by using this variable
        private double _bulletCooldownTimer = 0;

        private int _playerScore = 0;
        private static Random Rand = new Random();

        private GameState _currentGameState = GameState.MainMenu;

        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
        }

        protected override void Initialize()
        {
            _graphics.PreferredBackBufferWidth = 1024;
            _graphics.PreferredBackBufferHeight = 768;
            _graphics.ApplyChanges();

            _playerPosition = new Vector2(512, 700);

            _backgroundPosition1 = Vector2.Zero;
            _backgroundPosition2 = new Vector2(0, -_graphics.PreferredBackBufferHeight);

            base.Initialize();
        }

        protected override void LoadContent()
        {
            _spriteBatch = new SpriteBatch(GraphicsDevice);

            _backgroundTexture = Content.Load<Texture2D>("Graphics/Backround");
            _playerTexture = Content.Load<Texture2D>("Graphics/SpaceShip");
            _enemyTexture = Content.Load<Texture2D>("Graphics/enemy");
            _bulletTexture = Content.Load<Texture2D>("Graphics/Bullet");
            _startButtonTexture = Content.Load<Texture2D>("Graphics/startbutton");

            _shootSound = Content.Load<SoundEffect>("Audio/invaderkilled");
            _explosionSound = Content.Load<SoundEffect>("Audio/invaderkilled");
            _backgroundMusic = Content.Load<Song>("Audio/space-station-247790");

            MediaPlayer.IsRepeating = true;
            MediaPlayer.Play(_backgroundMusic);

            _startButtonRectangle = new Rectangle(412, 300, 200, 50);
        }

        protected override void Update(GameTime gameTime)
        {
            if (Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            switch (_currentGameState)
            {
                case GameState.MainMenu:
                    HandleMainMenuInput();
                    break;

                case GameState.Playing:
                    HandlePlayerInput(gameTime);
                    UpdateBackground(gameTime);
                    UpdateBullets(gameTime);
                    UpdateEnemies(gameTime);

                    // Use SpawnEnemies to spawn enemies
                    SpawnEnemies(gameTime);

                    CheckCollisions();
                    break;

                case GameState.GameOver:
                    HandleGameOverInput();
                    break;
            }

            base.Update(gameTime);
        }

        private void HandleMainMenuInput()
        {
            if (Mouse.GetState().LeftButton == ButtonState.Pressed &&
                _startButtonRectangle.Contains(Mouse.GetState().Position))
            {
                _currentGameState = GameState.Playing;
            }
        }

        private void HandleGameOverInput()
        {
            if (Keyboard.GetState().IsKeyDown(Keys.R))
            {
                ResetGame();
            }
        }

        private void HandlePlayerInput(GameTime gameTime)
        {
            KeyboardState state = Keyboard.GetState();
            float deltaTime = (float)gameTime.ElapsedGameTime.TotalSeconds;

            if (state.IsKeyDown(Keys.Left) && _playerPosition.X > 0)
                _playerPosition.X -= _playerSpeed * deltaTime;

            if (state.IsKeyDown(Keys.Right) && _playerPosition.X < _graphics.PreferredBackBufferWidth - (_playerTexture.Width * _playerScale))
                _playerPosition.X += _playerSpeed * deltaTime;

            if (state.IsKeyDown(Keys.Space))
            {
                if (_bulletCooldownTimer <= 0)
                {
                    ShootBullet();
                    _bulletCooldownTimer = 0.5;
                }
            }

            _bulletCooldownTimer -= deltaTime;
        }

        private void ShootBullet()
        {
            Vector2 bulletPosition = new Vector2(
                _playerPosition.X + (_playerTexture.Width * _playerScale) / 2 - _bulletTexture.Width / 2,
                _playerPosition.Y);
            _bullets.Add(new Bullet(_bulletTexture, bulletPosition, new Vector2(0, -400)));
            _shootSound.Play();
        }

        private void UpdateBullets(GameTime gameTime)
        {
            foreach (var bullet in _bullets.ToArray())
            {
                bullet.Update(gameTime, _graphics.PreferredBackBufferHeight);

                if (!bullet.IsMoving)
                {
                    _bullets.Remove(bullet);
                }

                foreach (var enemy in _enemies.ToArray())
                {
                    if (CollisionDetection.CheckCollision(bullet.BoundingBox, enemy.BoundingBox))
                    {
                        _explosionSound.Play();
                        _bullets.Remove(bullet);
                        _enemies.Remove(enemy);
                        _playerScore++;
                        break;
                    }
                }
            }
        }

        private void UpdateEnemies(GameTime gameTime)
        {
            foreach (var enemy in _enemies.ToArray())
            {
                enemy.Update(gameTime, _graphics.PreferredBackBufferWidth, _graphics.PreferredBackBufferHeight);

                if (!enemy.IsAlive)
                {
                    _enemies.Remove(enemy);
                }
            }
        }

        private void SpawnEnemies(GameTime gameTime)
        {
            _enemySpawnTimer += gameTime.ElapsedGameTime.TotalSeconds;

            if (_enemySpawnTimer >= 1.0)
            {
                Vector2 position = new Vector2(
                    Rand.Next(0, _graphics.PreferredBackBufferWidth - (int)(_enemyTexture.Width * 0.5f)), 0);
                Vector2 velocity = new Vector2(0, Rand.Next(100, 300));

                Enemy enemy = new Enemy(_enemyTexture, position, velocity)
                {
                    Scale = 0.5f
                };
                _enemies.Add(enemy);

                _enemySpawnTimer = 0;
            }
        }

        private void UpdateBackground(GameTime gameTime)
        {
            float deltaTime = (float)gameTime.ElapsedGameTime.TotalSeconds;

            _backgroundPosition1.Y += _backgroundScrollSpeed * deltaTime;
            _backgroundPosition2.Y += _backgroundScrollSpeed * deltaTime;

            if (_backgroundPosition1.Y >= _graphics.PreferredBackBufferHeight)
                _backgroundPosition1.Y = _backgroundPosition2.Y - _graphics.PreferredBackBufferHeight;

            if (_backgroundPosition2.Y >= _graphics.PreferredBackBufferHeight)
                _backgroundPosition2.Y = _backgroundPosition1.Y - _graphics.PreferredBackBufferHeight;
        }

        private void CheckCollisions()
        {
            foreach (var enemy in _enemies)
            {
                if (CollisionDetection.CheckCollision(
                    new Rectangle(
                        (int)_playerPosition.X,
                        (int)_playerPosition.Y,
                        (int)(_playerTexture.Width * _playerScale),
                        (int)(_playerTexture.Height * _playerScale)),
                    enemy.BoundingBox))
                {
                    _currentGameState = GameState.GameOver;
                }
            }
        }

        private void ResetGame()
        {
            _currentGameState = GameState.MainMenu;
            _playerScore = 0;
            _enemies.Clear();
            _bullets.Clear();
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.Black);

            _spriteBatch.Begin();

            switch (_currentGameState)
            {
                case GameState.MainMenu:
                    _spriteBatch.Draw(_startButtonTexture, _startButtonRectangle, Color.White);
                    break;

                case GameState.Playing:
                    _spriteBatch.Draw(
                        _backgroundTexture,
                        new Rectangle(0, 0, _graphics.PreferredBackBufferWidth, _graphics.PreferredBackBufferHeight),
                        Color.White);

                    _spriteBatch.Draw(
                        _playerTexture,
                        _playerPosition,
                        null,
                        Color.White,
                        0f,
                        Vector2.Zero,
                        _playerScale,
                        SpriteEffects.None,
                        0f);

                    foreach (var enemy in _enemies)
                        enemy.Draw(_spriteBatch);

                    foreach (var bullet in _bullets)
                        bullet.Draw(_spriteBatch);

                    _spriteBatch.DrawString(
                        Content.Load<SpriteFont>("Fonts/GameFont"),
                        $"Score: {_playerScore}",
                        new Vector2(10, 10),
                        Color.White);
                    break;

                case GameState.GameOver:
                    string gameOverText = "Game Over!";
                    Vector2 gameOverSize = Content.Load<SpriteFont>("Fonts/GameFont").MeasureString(gameOverText);
                    Vector2 gameOverPosition = new Vector2(
                        (_graphics.PreferredBackBufferWidth - gameOverSize.X) / 2,
                        (_graphics.PreferredBackBufferHeight - gameOverSize.Y) / 2 - 50);

                    _spriteBatch.DrawString(
                        Content.Load<SpriteFont>("Fonts/GameFont"),
                        gameOverText,
                        gameOverPosition,
                        Color.Red);

                    string restartText = "Press R to Restart";
                    Vector2 restartSize = Content.Load<SpriteFont>("Fonts/GameFont").MeasureString(restartText);
                    Vector2 restartPosition = new Vector2(
                        (_graphics.PreferredBackBufferWidth - restartSize.X) / 2,
                        gameOverPosition.Y + gameOverSize.Y + 20);

                    _spriteBatch.DrawString(
                        Content.Load<SpriteFont>("Fonts/GameFont"),
                        restartText,
                        restartPosition,
                        Color.White);
                    break;
            }

            _spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
